import java.util.Scanner;
import sorting.Sorter;
public class BinarySearch {
    static int size;
    static int indx;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Array size:");
        int size = scanner.nextInt();
        int[] nums = new int[size];
        System.out.println("enter numbers");
        for (int i = 0; i < nums.length; i++) {
            nums[i] = scanner.nextInt();
        }
        Sorter.sort(nums);
        System.out.println("------------------------");
        System.out.println("Your array:");
        int t = 0;
        for (int num : nums) {
            System.out.print(num + " ");
            t++;
            if (t % 10 == 0) {
                System.out.println("");
            }
        }
        System.out.println("");
        System.out.println("number search");
        int number = scanner.nextInt();
        if (number > nums[size - 1]) {
            System.err.println("wrong number");
        } else {
            int indx = binarySearch(nums, number, 0, nums.length);
            if (indx == -1) {
                System.err.println("not found :(");
            } else {
                System.out.println("index: " + indx);
            }
        }
        scanner.close();
    }

    public static int binarySearch(int[] array, int key, int low, int high) {
        if (low > high) {
            return -1;
        }
        int middle = low + (high - low) / 2;
        if (array[middle] == key) {
            return middle;
        } else if (array[middle] > key) {
            return binarySearch(array, key, low, middle - 1);
        } else if (array[middle] < key) {
            return binarySearch(array, key, middle + 1, high);
        }
        return 0;
    }
}
