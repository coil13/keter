public class Sorter {

	public static void sort(int[] array) {
		for (int out = array.length - 1; out >= 1; out--) {
			for (int in = 0; in < out; in++) {
				if (array[in] > array[in + 1]) {
					swap(in, in + 1, array);
				}
			}
		}
	}

	public static void swap(int first, int second, int[] array) {

		int a = array[first];
		int b = array[second];
		array[first] = b;
		array[second] = a;
	}

}
